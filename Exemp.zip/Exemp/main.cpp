#include <windows.h>
#include <gl/gl.h>
#include <math.h>
#include <iostream>
#include "main.h"
#include "mEnu.h"
#include "tExtur.h"


using namespace std;

LRESULT CALLBACK WindowProc(HWND, UINT, WPARAM, LPARAM); // объявление прототипа функции обработки сообщений окна
void EnableOpenGL(HWND hwnd, HDC*, HGLRC*);// объявление прототипа функции инициализации OpenGL
void DisableOpenGL(HWND, HDC, HGLRC);// объявление прототипа функции выключения OpenGL

int vx=0;

int WINAPI WinMain(HINSTANCE hInstance,
                   HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine,
                   int nCmdShow)// объявление функции WinMain, которая является точкой входа приложения
{
    WNDCLASSEX wcex;
    HWND hwnd;
    HDC hDC;
    HGLRC hRC;
    MSG msg;
    BOOL bQuit = FALSE;

    /* register window class */
    wcex.cbSize = sizeof(WNDCLASSEX);// размер структуры
    wcex.style = CS_OWNDC;// стиль класса окна
    wcex.lpfnWndProc = WindowProc;// указатель на функцию обработки сообщений окна
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;// дескриптор экземпляра приложения
    wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);// идентификатор иконки приложения
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);// идентификатор курсора
    wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);// кисть для заполнения фона окна
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = "GLSample";// имя класса окна
    wcex.hIconSm = LoadIcon(NULL, IDI_APPLICATION);;// идентификатор маленькой иконки приложения


    if (!RegisterClassEx(&wcex))// регистрация класса окна
        return 0;

    /* create main window */
    hwnd = CreateWindowEx(0,
                          "GLSample",// имя класса окна
                          "Main File Game",// заголовок окна
                          WS_OVERLAPPEDWINDOW,// стиль окна
                          CW_USEDEFAULT,// положение по X
                          CW_USEDEFAULT,// положение по Y
                          width,// ширина окна
                          height,// высота окна
                          NULL,
                          NULL,
                          hInstance,
                          NULL);

    ShowWindow(hwnd, nCmdShow);// показать окно

    /* enable OpenGL for the window */
    EnableOpenGL(hwnd, &hDC, &hRC);// инициализация OpenGL




    Main_Init();// вызов функции инициализации игры
    Menu_Init();// вызов функции инициализации меню
    RECT rct; //создание переменной с координатами прямоуголника
    GetClientRect(hwnd, &rct);  //получение текущих координат окна
    glOrtho(0,rct.right,0,rct.bottom,1,-1);  //выставляем их как координаты окна

    /* program main loop */
    while (!bQuit)
    {
        /* check for messages */
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            /* handle or dispatch messages */
            if (msg.message == WM_QUIT)
            {
                bQuit = TRUE;
            }
            else
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }
        else
        {
            /* OpenGL animation code goes here */

            glClearColor(0.8f, 0.5f, 0.3f, 0.5f);// Задаем цвет очистки буфера (красный, зеленый, синий, альфа-канал)
            glClear(GL_COLOR_BUFFER_BIT);// Очищаем буфер цвета

            Show_Background(background);// Отображаем задний фон

            if (gameState==1)// Если игровое состояние равно 1, то продолжаем игру
            {


                Hero_Move(&pers);// Двигаем героя

                Hero_Show(&pers);// Отображаем героя



            };

            glPushMatrix();
            glLoadIdentity();// Сохраняем текущую матрицу в стек матриц, загружаем единичную матрицу
            glOrtho(0,rct.right,rct.bottom, 0,1,-1);// Устанавливаем ортографическую проекцию на весь экран
            Menu_ShowMenu();// Отображаем меню
            glPopMatrix();// Восстанавливаем матрицу из стека матриц

            SwapBuffers(hDC);// Обмениваем буферы, выводим изображение на экран
            Sleep (1);// Задержка на 1 миллисекунду

        }
    }

    /* shutdown OpenGL */
    DisableOpenGL(hwnd, hDC, hRC);

    /* destroy the window explicitly */
    DestroyWindow(hwnd);

    return msg.wParam;
}

LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)//начало оператора выбора в зависимости от значения uMsg
    {
    case WM_CLOSE://случай, когда приложение получает сообщение о закрытии окна
        PostQuitMessage(0);
        break;

    case WM_DESTROY://случай, когда окно разрушается
        return 0;

    case WM_MOUSEMOVE://случай, когда мышь перемещается в окне
        Menu_MouseMove(LOWORD(lParam), HIWORD(lParam));//вызов функции Menu_MouseMove с координатами мыши
        break;



    case WM_LBUTTONDOWN:// случай, когда нажата левая кнопка мыши
        MouseDown();
        break;

    case WM_LBUTTONUP://случай, когда отпущена левая кнопка мыши
        Menu_MouseUp();
        break;



    case WM_KEYDOWN://случай, когда нажата клавиша
    {
        switch (wParam)//начало оператора выбора в зависимости от значения wParam
        {
        case VK_ESCAPE://случай, когда нажата клавиша ESC
            PostQuitMessage(0);
            break;

        case VK_RETURN://случай, когда нажата клавиша Enter
            gameState=1;
            break;
        }
    }
    break;

    default:
        return DefWindowProc(hwnd, uMsg, wParam, lParam);//передача управления стандартной функции DefWindowProc для дальнейшей обработки сообщения
    }

    return 0;
}

void EnableOpenGL(HWND hwnd, HDC* hDC, HGLRC* hRC)
{
    PIXELFORMATDESCRIPTOR pfd;

    int iFormat;

    /* get the device context (DC) */
    *hDC = GetDC(hwnd);

    /* set the pixel format for the DC */
    ZeroMemory(&pfd, sizeof(pfd));

    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW |
                  PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 24;
    pfd.cDepthBits = 16;
    pfd.iLayerType = PFD_MAIN_PLANE;

    iFormat = ChoosePixelFormat(*hDC, &pfd);

    SetPixelFormat(*hDC, iFormat, &pfd);

    /* create and enable the render context (RC) */
    *hRC = wglCreateContext(*hDC);

    wglMakeCurrent(*hDC, *hRC);
}

void DisableOpenGL (HWND hwnd, HDC hDC, HGLRC hRC)
{
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(hRC);
    ReleaseDC(hwnd, hDC);
}

